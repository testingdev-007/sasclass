/*==========================================================================
  02  STEMMING, "LEMMING" APPROXIMATION, PHONETIC KEYS
  - stemw()      : regex suffix stripper (PROC FCMP wrapping PRXCHANGE)
  - cmp.lemma_map: irregular forms handled by hash lookup BEFORE stemming
  - soundex()    : phonetic key, used later as a fuzzy-match booster
  Out: cmp.ngrams_stem, cmp.kw_norm (keywords run through the SAME pipeline)
==========================================================================*/
proc fcmp outlib=cmp.funcs.text;
  function stemw(w $) $ 40;
    length s t $ 40;
    s = lowcase(strip(w));
    if lengthn(s) <= 3 then return(s);
    s = prxchange('s/sses$/ss/', 1, s);                            /* addresses -> address */
    if lengthn(s) > 4 then s = prxchange('s/ies$/y/', 1, s);       /* queries  -> query   */
    if lengthn(s) > 3 and prxmatch('/[^s]s$/', s) then
      s = substr(s, 1, lengthn(s) - 1);                            /* charges -> charge   */
    if prxmatch('/(ing|ed)$/', s) then do;
      t = prxchange('s/(ing|ed)$//', 1, s);
      if lengthn(t) >= 3 and prxmatch('/[aeiouy]/', t) then do;    /* must keep a vowel   */
        s = prxchange('s/([^aeioulsz])\1$/$1/', 1, t);             /* runn -> run         */
      end;
    end;
    if lengthn(s) > 3 then s = prxchange('s/e$//', 1, s);          /* charge -> charg     */
    if lengthn(s) > 5 then s = prxchange('s/(ment|ness)$//', 1, s);/* payment -> pay      */
    if lengthn(s) > 5 then s = prxchange('s/ly$//', 1, s);         /* incorrectly -> incorrect */
    if lengthn(s) > 3 and prxmatch('/[^aeiou]y$/', s) then
      s = cats(substr(s, 1, lengthn(s) - 1), 'i');                 /* apply/applied -> appli */
    return(s);
  endsub;
run;
options cmplib=cmp.funcs;

/*---- Quick self-test: eyeball the stemmer -------------------------------*/
data _stem_test;
  length word $30 stem $30 sdx $6;
  input word :$30. @@;
  stem = stemw(word); sdx = soundex(stem);
  datalines;
charges charged charging payment payments delayed delaying delays refused refuse
processing processed process queries complaints declined decline running address
;
run;
proc print data=_stem_test noobs; run;

/*---- Stemmed / lemmatised n-grams (same macro as step 01) ----------------*/
%make_ngrams(in=cmp.sentences, out=cmp.ngrams_stem, stem=1);

/*---- Normalise the keyword map through the identical pipeline ------------*/
data cmp.kw_norm;
  set cmp.kw_map;
  length word $40 lemma $40 w $40 clean $200 kw_stem $120;
  if _n_ = 1 then do;
    declare hash sw(dataset:'cmp.stopwords');
    sw.definekey('word'); sw.definedone();
    declare hash lm(dataset:'cmp.lemma_map');
    lm.definekey('word'); lm.definedata('lemma'); lm.definedone();
  end;
  clean = compbl(prxchange('s/[^a-z0-9 ]/ /', -1, lowcase(keyword)));
  ngram_n = 0; kw_stem = ' ';
  do p = 1 to countw(clean, ' ');
    w = scan(clean, p, ' ');
    word = w;
    if sw.check() = 0 then continue;
    lemma = ' ';
    if lm.find() = 0 then w = lemma;
    w = stemw(w);
    kw_stem = catx(' ', kw_stem, w);
    ngram_n + 1;
  end;
  kw_sdx = soundex(compress(kw_stem));
  if ngram_n in (1, 2, 3);          /* drop keywords that collapse to nothing or exceed trigram */
  drop word lemma w clean p;
run;

proc sql;
  title 'Keywords that collapsed after stopword removal (review these)';
  select kw_id, keyword, kw_stem, ngram_n from cmp.kw_norm where ngram_n = 1 and countw(keyword,' ') > 1;
quit; title;
