/*==========================================================================
  00c  SUPPORT TABLES + SAMPLE DATA
  cmp.stopwords, cmp.lemma_map, cmp.weight_matrix, cmp.complaints_raw
  NOTE: negations (not, no, never) are deliberately NOT stopwords.
==========================================================================*/
data cmp.stopwords;
  length word $40;
  infile datalines dlm=' ' truncover;
  input word :$40. @@;
  datalines;
a an the and or but if of to in on at by for with from as is are was were be been
being am it its this that these those i me my we our us you your he she they them
their have has had do does did done would could should will can may might must
so than then there here when what which who whom how why also just very really
please thank thanks dear regards sincerely hello hi again about into over under
out up down off after before while during because since until per via etc
;
run;

data cmp.lemma_map;                        /* irregular forms the suffix stripper can't fix */
  length word $40 lemma $40;
  infile datalines dlm=' ' truncover;
  input word :$40. lemma :$40. @@;
  datalines;
paid pay sent send told tell gave give took take lost lose kept keep made make
wrote write bought buy said say went go got get knew know felt feel left leave
charged charge refunded refund declined decline
;
run;

/*---- Weight matrix: how much each (field, section) counts, per purpose ---*/
data cmp.weight_matrix;
  length purpose $7 field $1 sect $7 w 8 rationale $70;
  infile datalines dlm='|' truncover;
  input purpose $ field $ sect $ w rationale $;
  datalines;
ROOT|D|CUST|0.35|Customer view: useful pointer, not proof of cause
ROOT|D|VENT|0.05|Venting: almost no causal information
ROOT|F|UPHELD|1.00|Business agreed: strongest root-cause evidence
ROOT|F|NEUTRAL|0.50|Investigation fact, no determination
ROOT|F|NOTUP|-0.30|Rejected aspect: evidence this is NOT the cause
ROOT|F|ADMIN|0.00|Case-handling notes: never a cause
TRIGGER|D|CUST|1.00|Customer own words drive trigger and emotion
TRIGGER|D|VENT|0.80|Venting is the best emotion signal
TRIGGER|F|UPHELD|0.20|Business acknowledgement of impact
TRIGGER|F|NEUTRAL|0.10|Little emotional content
TRIGGER|F|NOTUP|0.00|Not relevant to trigger
TRIGGER|F|ADMIN|0.00|Case-handling notes
;
run;

/*---- Sample complaints so the pipeline runs end-to-end -------------------*/
data cmp.complaints_raw;
  length complaint_id 8 description $1000 findings_of_investigation $1000;
  infile datalines dlm='|' truncover;
  input complaint_id description $ findings_of_investigation $;
  datalines;
1001|My standing order failed for the third month and I was charged twice for the overdraft. I have spent hours on the phone and I am furious. Absolutely disgraceful service!|Call ref 88231 logged. We reviewed the payment history and found the standing order failed because of a system error during the batch run. This aspect of the complaint is upheld. The overdraft charges were refunded.
1002|I was locked out of my account for two weeks and nobody would help. I am stressed and worried about my rent.|Case opened and forwarded to the security team. The verification failed because the ID check flagged a mismatch. We should have offered an alternative route. The complaint is upheld. We did not find evidence the account was closed in error.
1003|The advisor was rude and dismissive on the phone and told me the wrong thing about my loan. This is unacceptable.|We listened to the call recording. The advisor was not rude and acted professionally. This part is not upheld. However the advisor gave incorrect information about the settlement figure, which is upheld.
1004|Your collections team keep calling me daily even though I told them about my bereavement. I feel harassed and embarrassed.|Reviewed by team leader. Vulnerability was not recorded on the account so the collections contact continued. We did not recognise the bereavement. Complaint upheld and account notes updated.
1005|I sent money to what turned out to be a scammer. The bank gave me no warning at all. I am out of pocket and it is not fair.|The payment was in line with the customer instructions. We found the scam warning shown at the time was appropriate. Complaint not upheld. Email sent to the customer explaining the outcome.
1006|My loan application has been awaiting a decison for six weeks and I still waiting for an answer. I had to chase every week.|Application delay confirmed. The decision took longer than our standard because the file was queued. We agree this was our error. Complaint upheld. Compensation paid.
1007|A fee was applied to my acount and I was never told about it. Charges were not made clear.|We reviewed the account terms. The fee was correctly applied under the terms. Fee not disclosed at point of sale was not evidenced. Not upheld.
1008|They keyed my payment to the wrong account and I lost money. I feel misled and ignored.|The payment was processed incorrectly due to a manual error by the colleague who keyed the sort code. Upheld. Funds were recovered. Case closed.
;
run;
