/*==========================================================================
  01  SENTENCE SEGMENTATION, NOISE TAGGING, TOKENISATION, N-GRAMS
  In : cmp.complaints_raw, cmp.stopwords, (cmp.lemma_map when stem=1)
  Out: cmp.sentences  (one row per sentence, tagged with a section)
       cmp.ngrams_raw (unigrams, bigrams, trigrams on cleaned tokens)

  SECT codes
    description : CUST (factual customer narrative) | VENT (short pure venting)
    findings    : UPHELD | NOTUP (rejected aspect) | NEUTRAL | ADMIN (handler notes)
==========================================================================*/

/*---- 1. Split both fields into sentences and tag each one ----------------*/
data cmp.sentences;
  set cmp.complaints_raw;
  length field $1 text $2000 sent_text $600 sect $7;
  retain re_admin re_notup re_up re_vent;
  if _n_ = 1 then do;
    re_admin = prxparse('/\b(call ref|case (opened|closed|logged)|logged|forwarded to|email sent|reviewed by|team leader|listened to the call|acknowledg\w*|compensation paid|funds were recovered|notes updated)\b/i');
    re_notup = prxparse('/\b(not upheld|no evidence|did not find|acted (correctly|professionally)|was not rude|in line with|was appropriate|correctly applied|not evidenced)\b/i');
    re_up    = prxparse('/\b(upheld|we agree|our error|should have|was not recorded|we did not recognise|confirmed|failed because|due to a)\b/i');
    re_vent  = prxparse('/\b(disgrace\w*|outrage\w*|appalling|ridiculous|absolutely|furious|fed up|joke|useless|shambles)\b/i');
  end;

  do field = 'D', 'F';
    if field = 'D' then text = description; else text = findings_of_investigation;
    text = prxchange('s/(\d)\.(\d)/$1~$2/', -1, text);     /* protect decimals */
    nsent = countw(text, '.!?');
    do sent_no = 1 to nsent;
      sent_text = strip(translate(scan(text, sent_no, '.!?'), '.', '~'));
      if lengthn(sent_text) < 3 then continue;
      if field = 'D' then do;
        if prxmatch(re_vent, sent_text) and countw(sent_text, ' ') <= 10 then sect = 'VENT';
        else sect = 'CUST';
      end;
      else do;
        if      prxmatch(re_admin, sent_text) and not prxmatch(re_up, sent_text) then sect = 'ADMIN';
        else if prxmatch(re_notup, sent_text) then sect = 'NOTUP';  /* checked BEFORE upheld: "not upheld" contains "upheld" */
        else if prxmatch(re_up,    sent_text) then sect = 'UPHELD';
        else sect = 'NEUTRAL';
      end;
      output;
    end;
  end;
  keep complaint_id field sent_no sent_text sect;
run;

/*---- 2. Reusable tokeniser / n-gram macro --------------------------------*/
%macro make_ngrams(in=cmp.sentences, out=cmp.ngrams_raw, stem=0, maxn=3);
data &out.(keep=complaint_id field sent_no sect n ngram);
  set &in.(where=(sect ne 'ADMIN'));            /* admin notes never reach the vocabulary */
  length word $40 lemma $40 w $40 clean $700 ngram $120;
  array kw{200} $40 _temporary_;
  if _n_ = 1 then do;
    declare hash sw(dataset:'cmp.stopwords');
    sw.definekey('word'); sw.definedone();
    %if &stem. %then %do;
      declare hash lm(dataset:'cmp.lemma_map');
      lm.definekey('word'); lm.definedata('lemma'); lm.definedone();
    %end;
  end;

  clean = compbl(prxchange('s/[^a-z0-9 ]/ /', -1, lowcase(sent_text)));
  k = 0;
  do p = 1 to countw(clean, ' ');
    w = scan(clean, p, ' ');
    if lengthn(w) < 2 then continue;
    if anydigit(w) and not anyalpha(w) then continue;     /* pure numbers */
    word = w;
    if sw.check() = 0 then continue;                       /* stopword */
    %if &stem. %then %do;
      lemma = ' ';
      if lm.find() = 0 then w = lemma;                     /* irregular -> lemma */
      w = stemw(w);                                        /* suffix stripping (FCMP, file 02) */
    %end;
    if k >= 200 then leave;
    k + 1;
    kw{k} = w;
  end;

  do n = 1 to &maxn.;
    do i = 1 to k - n + 1;
      ngram = kw{i};
      do j = 1 to n - 1;
        ngram = catx(' ', ngram, kw{i + j});
      end;
      output;
    end;
  end;
run;
%mend make_ngrams;

%make_ngrams(in=cmp.sentences, out=cmp.ngrams_raw, stem=0);

proc freq data=cmp.sentences; tables field*sect / nopercent norow nocol; run;
proc sql outobs=15;
  title 'Top raw bigrams'; select ngram, count(*) as freq from cmp.ngrams_raw
   where n=2 group by ngram order by freq desc;
quit; title;
