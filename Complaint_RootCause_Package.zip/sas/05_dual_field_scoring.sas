/*==========================================================================
  05  WEIGHTED DUAL-FIELD SCORING  ->  ROOT CAUSE (L1/L2/L3) + TRIGGER + EMOTION
  hit_score = kw_weight x match_quality x idf_boost x weight_matrix(purpose, field, sect)
    ROOT    purpose: findings UPHELD sentences dominate (1.00), customer text is a
                     pointer (0.35), rejected (NOTUP) evidence is subtracted (-0.30)
    TRIGGER purpose: customer text dominates (1.00), venting still counts (0.80)
  Repeats of one keyword get diminishing returns: (1 + ln count) / count.
  In : cmp.kw_hits, cmp.weight_matrix, cmp.sentences, cmp.df_idf, cmp.tax_*
  Out: cmp.class_evidence, cmp.complaint_class
==========================================================================*/
%let min_root  = 0.40;    /* minimum root score to auto-classify            */
%let min_conf  = 0.55;    /* top / (top + runner-up) needed to auto-classify */
%let emo_high  = 1.50;    /* emotion index bands                            */
%let emo_med   = 0.75;

proc sql noprint;
  select max(idf) into :idf_ref trimmed from cmp.df_idf;
quit;

/*---- 1. Weight every hit --------------------------------------------------*/
proc sql;
  create table work.hit_w as
  select h.*,
         h.kw_weight * h.match_q * (0.5 + 0.5 * min(h.idf / &idf_ref., 1)) * w.w as hit_score
    from cmp.kw_hits h
    inner join cmp.weight_matrix w
       on w.purpose = h.kw_type and w.field = h.field and w.sect = h.sect;

  /*---- 2. Per keyword: damp repeats, keep the D and F contributions apart -*/
  create table cmp.class_evidence as
  select h.complaint_id, h.kw_type, h.l3_id, h.trg_id, h.kw_id, k.keyword,
         count(*) as cnt,
         (1 + log(calculated cnt)) / calculated cnt
           * sum(case when h.field = 'D' then h.hit_score else 0 end) as d_score,
         (1 + log(calculated cnt)) / calculated cnt
           * sum(case when h.field = 'F' then h.hit_score else 0 end) as f_score
    from work.hit_w h inner join cmp.kw_map k on h.kw_id = k.kw_id
   group by h.complaint_id, h.kw_type, h.l3_id, h.trg_id, h.kw_id, k.keyword;

  /*---- 3. Roll up to L3 candidates and to trigger categories -------------*/
  create table work.root as
  select complaint_id, l3_id, sum(d_score) as d_score, sum(f_score) as f_score,
         sum(d_score + f_score) as root_score
    from cmp.class_evidence where kw_type = 'ROOT'
   group by complaint_id, l3_id;

  create table work.trig as
  select complaint_id, trg_id, sum(d_score + f_score) as trg_score
    from cmp.class_evidence where kw_type = 'TRIGGER'
   group by complaint_id, trg_id;

  create table work.emo as
  select complaint_id, sum(trg_score) as emo_index from work.trig group by complaint_id;

  /*---- 4. Investigation profile: how much did the business uphold? -------*/
  create table work.f_profile as
  select complaint_id,
         sum(field = 'F' and sect = 'UPHELD') as n_up,
         sum(field = 'F' and sect = 'NOTUP')  as n_notup,
         sum(field = 'D' and sect = 'VENT')   as n_vent
    from cmp.sentences group by complaint_id;
quit;

/*---- 5. Pick winners (sorted descending, first two rows per complaint) ----*/
proc sort data=work.root; by complaint_id descending root_score; run;
data work.root_top;
  set work.root; by complaint_id;
  length top_l3 $8;
  retain rank top_l3 top_score top_d top_f second_score;
  if first.complaint_id then do; rank = 0; second_score = 0; end;
  rank + 1;
  if rank = 1 then do; top_l3 = l3_id; top_score = root_score; top_d = d_score; top_f = f_score; end;
  else if rank = 2 then second_score = root_score;
  if last.complaint_id then do;
    conf = ifn(top_score > 0, top_score / (top_score + max(second_score, 0)), .);
    output;
  end;
  keep complaint_id top_l3 top_score top_d top_f second_score conf;
run;

proc sort data=work.trig; by complaint_id descending trg_score; run;
data work.trig_top;
  set work.trig; by complaint_id;
  if first.complaint_id then output;
  keep complaint_id trg_id trg_score;
run;

/*---- 6. Assemble the classification with status logic ---------------------*/
proc sql;
  create table work.assembled as
  select c.complaint_id, r.top_l3 as l3_id, r.top_score as root_score,
         r.top_d as root_from_customer, r.top_f as root_from_findings,
         r.conf as root_conf, t.trg_id, t.trg_score, e.emo_index,
         p.n_up, p.n_notup, p.n_vent
    from cmp.complaints_raw c
    left join work.root_top r on c.complaint_id = r.complaint_id
    left join work.trig_top t on c.complaint_id = t.complaint_id
    left join work.emo      e on c.complaint_id = e.complaint_id
    left join work.f_profile p on c.complaint_id = p.complaint_id;

  create table cmp.complaint_class as
  select a.*, l3.l3_name, l2.l2_id, l2.l2_name, l1.l1_id, l1.l1_name, tr.trg_name
    from work.assembled a
    left join cmp.tax_l3 l3      on a.l3_id  = l3.l3_id
    left join cmp.tax_l2 l2      on l3.l2_id = l2.l2_id
    left join cmp.tax_l1 l1      on l2.l1_id = l1.l1_id
    left join cmp.tax_trigger tr on a.trg_id = tr.trg_id;
quit;

data cmp.complaint_class;
  set cmp.complaint_class;
  length class_status $22 emo_band $6 outcome_signal $10;
  if      n_up > 0 and n_notup > 0 then outcome_signal = 'PARTIAL';
  else if n_up > 0                 then outcome_signal = 'UPHELD';
  else if n_notup > 0              then outcome_signal = 'NOT UPHELD';
  else                                  outcome_signal = 'NONE';

  if      root_score >= &min_root. and root_conf >= &min_conf. and root_from_findings > 0
                                                   then class_status = 'CLASSIFIED';
  else if root_score ne . and root_from_findings <= 0 and outcome_signal = 'NOT UPHELD'
                                                   then class_status = 'ALLEGED_NOT_UPHELD';
  else if root_score > 0 and root_from_findings <= 0
                                                   then class_status = 'CUSTOMER_VIEW_ONLY';
  else if root_score > 0                           then class_status = 'LOW_CONFIDENCE_REVIEW';
  else                                                  class_status = 'UNCLASSIFIED';

  emo_index = coalesce(emo_index, 0);
  if      emo_index >= &emo_high. then emo_band = 'HIGH';
  else if emo_index >= &emo_med.  then emo_band = 'MEDIUM';
  else                                 emo_band = 'LOW';
run;

proc print data=cmp.complaint_class noobs label;
  var complaint_id l1_name l2_name l3_name root_score root_conf class_status
      outcome_signal trg_name emo_index emo_band;
  format root_score root_conf emo_index 5.2;
run;

/*---- Explainability: why did complaint 1005 end up where it did? ----------*/
proc print data=cmp.class_evidence noobs;
  where complaint_id = 1005;
  var kw_type keyword cnt d_score f_score;
run;
