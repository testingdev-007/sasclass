/*==========================================================================
  06  RELATIONAL INTEGRITY FOR THE TAXONOMY (no database server needed)
  Base SAS datasets support primary keys, foreign keys, CHECK constraints and
  indexes.  Run AFTER 00a-00c.  To re-seed 00a-00c later, run the RESET block
  first (SAS will not replace a table another table's foreign key points at).
==========================================================================*/

/*---- RESET (uncomment before re-running 00a-00c) -------------------------
proc datasets lib=cmp nolist;
  modify kw_map;   ic delete _all_;
  modify tax_l3;   ic delete _all_;
  modify tax_l2;   ic delete _all_;
  modify tax_l1;   ic delete _all_;
  modify tax_trigger; ic delete _all_;
quit;
---------------------------------------------------------------------------*/

proc sql;
  /* primary keys: parents first */
  alter table cmp.tax_l1      add constraint pk_l1  primary key (l1_id);
  alter table cmp.tax_l2      add constraint pk_l2  primary key (l2_id);
  alter table cmp.tax_l3      add constraint pk_l3  primary key (l3_id);
  alter table cmp.tax_trigger add constraint pk_trg primary key (trg_id);
  alter table cmp.kw_map      add constraint pk_kw  primary key (kw_id);

  /* foreign keys: a parent cannot be deleted or re-keyed while children exist */
  alter table cmp.tax_l2 add constraint fk_l2_l1 foreign key (l1_id)
        references cmp.tax_l1 on delete restrict on update restrict;
  alter table cmp.tax_l3 add constraint fk_l3_l2 foreign key (l2_id)
        references cmp.tax_l2 on delete restrict on update restrict;
  alter table cmp.kw_map add constraint fk_kw_l3 foreign key (l3_id)
        references cmp.tax_l3 on delete restrict on update restrict;
  alter table cmp.kw_map add constraint fk_kw_trg foreign key (trg_id)
        references cmp.tax_trigger on delete restrict on update restrict;

  /* business rules */
  alter table cmp.kw_map add constraint ck_kw_type
        check (kw_type in ('ROOT', 'TRIGGER'));
  alter table cmp.kw_map add constraint ck_kw_parent   /* exactly one parent, matching the type */
        check ((kw_type = 'ROOT'    and l3_id  is not missing and trg_id is missing)
            or (kw_type = 'TRIGGER' and trg_id is not missing and l3_id  is missing));
  alter table cmp.kw_map add constraint ck_kw_weight check (kw_weight between 0 and 1);
quit;
/* NOTE: if your SAS release rejects missing values in the two nullable foreign
   keys on kw_map, drop fk_kw_l3/fk_kw_trg; ck_kw_parent plus the orphan check
   in 00b still guarantee referential integrity. */

/*---- Indexes for the lookups the pipeline repeats -----------------------*/
proc datasets lib=cmp nolist;
  modify kw_map;    index create kw_type;  index create l3_id;
  modify tax_l3;    index create l2_id;
  modify tax_l2;    index create l1_id;
quit;

/*---- One flat path view for reporting: L1 > L2 > L3 ----------------------*/
proc sql;
  create view cmp.v_taxonomy_path as
  select l3.l3_id, l3.l3_name, l2.l2_id, l2.l2_name, l1.l1_id, l1.l1_name,
         catx(' > ', l1.l1_name, l2.l2_name, l3.l3_name) as full_path length=160
    from cmp.tax_l3 l3
    inner join cmp.tax_l2 l2 on l3.l2_id = l2.l2_id
    inner join cmp.tax_l1 l1 on l2.l1_id = l1.l1_id
   where l3.active_flag = 1 and l2.active_flag = 1 and l1.active_flag = 1;
quit;

/*---- Change control: append-only audit of keyword edits ------------------*/
proc sql;
  create table cmp.kw_audit
   (audit_id num, kw_id num, action char(8), old_value char(60), new_value char(60),
    changed_by char(32), changed_dttm num format=datetime20., reason char(120));
quit;
