/*==========================================================================
  00a  SETUP + 3-LEVEL TAXONOMY  (Base SAS / Enterprise Guide program node)
  Creates:  cmp.tax_l1, cmp.tax_l2, cmp.tax_l3, cmp.tax_trigger, cmp.kw_map
  Run once (re-run to reset the seed). Edit &root. to any writable folder.
==========================================================================*/
%let root = /sasdata/complaints;      /* EDIT: e.g. C:\Temp\cmp on Windows  */
libname cmp "&root.";
options nosymbolgen nomprint validvarname=v7;

/*---- LEVEL 1 : Domain / product area ------------------------------------*/
data cmp.tax_l1;
  length l1_id $4 l1_name $40 l1_desc $120 active_flag 8 valid_from valid_to 8;
  format valid_from valid_to date9.;
  infile datalines dlm='|' truncover;
  input l1_id $ l1_name $ l1_desc $;
  active_flag = 1; valid_from = '01JAN2026'd; valid_to = '31DEC9999'd;
  datalines;
PAY|Payments & Transfers|Money movement: faster payments, standing orders, cards, fraud and scams
ACC|Account Servicing|Access, changes, fees and charges on existing accounts
LND|Lending & Credit|Applications, affordability decisions, arrears and collections
SVC|Service & Conduct|How we communicated, handled the complaint and treated the customer
;
run;

/*---- LEVEL 2 : Sub-process / failure type (FK -> l1_id) ------------------*/
data cmp.tax_l2;
  length l2_id $6 l1_id $4 l2_name $50 active_flag 8;
  infile datalines dlm='|' truncover;
  input l2_id $ l1_id $ l2_name $;
  active_flag = 1;
  datalines;
PAY01|PAY|Failed or delayed payment
PAY02|PAY|Fraud and scam handling
ACC01|ACC|Account access and changes
ACC02|ACC|Fees and charges
LND01|LND|Application and decisioning
LND02|LND|Arrears and collections
SVC01|SVC|Communication and complaint handling
SVC02|SVC|Staff conduct and advice
;
run;

/*---- LEVEL 3 : Specific root cause (FK -> l2_id) -------------------------*/
data cmp.tax_l3;
  length l3_id $8 l2_id $6 l3_name $50 l3_def $160 active_flag 8;
  infile datalines dlm='|' truncover;
  input l3_id $ l2_id $ l3_name $ l3_def $;
  active_flag = 1;
  datalines;
PAY01.1|PAY01|System or processing fault|Payment failed or was delayed because of a system, batch or technical fault
PAY01.2|PAY01|Manual processing error|Payment failed or went wrong because a colleague keyed or actioned it incorrectly
PAY02.1|PAY02|Fraud alert not actioned|Fraud warning, block or report was not acted on in time
PAY02.2|PAY02|Inadequate scam warning|Customer was not given a clear scam warning or intervention
ACC01.1|ACC01|Lockout or verification friction|Customer could not access the account because of ID or security checks
ACC01.2|ACC01|Incorrect account change|Details or settings were changed wrongly or without consent
ACC02.1|ACC02|Fee wrongly applied|A fee or charge was applied that should not have been
ACC02.2|ACC02|Fee not disclosed|Fee or interest was not made clear before it applied
LND01.1|LND01|Incorrect affordability decision|Application declined or approved on wrong affordability assessment
LND01.2|LND01|Application delay|Application or decision took longer than promised
LND02.1|LND02|Inappropriate arrears contact|Collections contact was too frequent, wrong channel or wrong tone
LND02.2|LND02|Vulnerability not recognised|Signs of vulnerability were missed or not acted on
SVC01.1|SVC01|No response or chasing|Customer had to chase, or no reply was given within timescale
SVC01.2|SVC01|Incorrect information given|Customer was given wrong or conflicting information
SVC02.1|SVC02|Poor advice|Advice given was unsuitable or misleading
SVC02.2|SVC02|Unprofessional handling|Rude, dismissive or unprofessional treatment
;
run;

/*---- Trigger categories (WHY the customer felt compelled to complain) ----*/
data cmp.tax_trigger;
  length trg_id $4 trg_name $40 trg_def $100;
  infile datalines dlm='|' truncover;
  input trg_id $ trg_name $ trg_def $;
  datalines;
T01|Financial loss or hardship|Money lost, charged or put at risk
T02|Time and effort lost|Chasing, waiting, repeated contact
T03|Trust and fairness|Felt misled, ignored or treated unfairly
T04|Distress and anxiety|Worry, stress, embarrassment
T05|Anger and outrage|Strong anger, unacceptable service
;
run;
