/*==========================================================================
  03  TF-IDF  (PROC SQL for corpus statistics, HASH for the row-level join)
  Document = one complaint.  Term = stemmed n-gram (1-3).
  Tunables: &min_df. drops one-off typos/noise, &max_df_pct. drops boilerplate
  In : cmp.ngrams_stem
  Out: cmp.tf, cmp.df_idf, cmp.tfidf (L2-normalised per complaint+field)
==========================================================================*/
%let min_df     = 1;      /* raise to 2+ on a real corpus (25k rows: try 3) */
%let max_df_pct = 0.80;   /* ignore terms appearing in >80% of complaints  */

/*---- 1. Term frequency per complaint+field, sub-linear (1 + ln tf) -------*/
proc sql;
  create table cmp.tf as
  select complaint_id, field, n, ngram, count(*) as tf,
         1 + log(count(*)) as tf_log
    from cmp.ngrams_stem
   group by complaint_id, field, n, ngram;

  /*---- 2. Document frequency + smoothed IDF ------------------------------*/
  select count(distinct complaint_id) into :ndocs trimmed from cmp.ngrams_stem;

  create table cmp.df_idf as
  select ngram, n, count(distinct complaint_id) as df,
         log((1 + &ndocs.) / (1 + count(distinct complaint_id))) + 1 as idf
    from cmp.ngrams_stem
   group by ngram, n
  having calculated df >= &min_df.
     and calculated df <= &max_df_pct. * &ndocs.;
quit;
%put NOTE: corpus size = &ndocs. complaints;

/*---- 3. Hash lookup join (much faster than SQL join on a big vocabulary) -*/
data cmp.tfidf_raw;
  if _n_ = 1 then do;
    length ngram $120 n 8 df 8 idf 8;
    declare hash h(dataset:'cmp.df_idf');
    h.definekey('ngram', 'n');
    h.definedata('df', 'idf');
    h.definedone();
    call missing(df, idf);
  end;
  set cmp.tf;
  if h.find() = 0 then do;
    tfidf = tf_log * idf;
    output;
  end;
run;

/*---- 4. L2-normalise each complaint+field vector (cosine-ready) ----------*/
proc sql;
  create table cmp.tfidf as
  select a.*, a.tfidf / b.norm as tfidf_norm
    from cmp.tfidf_raw a
    inner join (select complaint_id, field, sqrt(sum(tfidf**2)) as norm
                  from cmp.tfidf_raw group by complaint_id, field) b
      on a.complaint_id = b.complaint_id and a.field = b.field;
quit;

proc sql outobs=15;
  title 'Highest-weight terms in complaint 1001 (customer field)';
  select ngram, tf, round(idf,.01) as idf, round(tfidf,.01) as tfidf
    from cmp.tfidf where complaint_id=1001 and field='D' order by tfidf desc;
quit; title;
