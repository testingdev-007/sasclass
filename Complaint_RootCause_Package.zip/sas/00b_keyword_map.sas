/*==========================================================================
  00b  KEYWORD MAP  (what you type is normalised by the SAME pipeline as the
  complaint text - see 04 - so plural/tense/stopword differences don't matter)
  kw_type = ROOT    -> l3_id populated  (root-cause evidence)
  kw_type = TRIGGER -> trg_id populated (customer emotion / intent evidence)
  kw_weight: 1.0 = strong/specific   0.5 = supportive   0.25 = weak
==========================================================================*/
data cmp.kw_map;
  length kw_id 8 kw_type $7 l3_id $8 trg_id $4 keyword $60 kw_weight 8 source $8;
  infile datalines dlm='|' dsd truncover;   /* DSD: '||' = missing value */
  input kw_type $ l3_id $ trg_id $ keyword $ kw_weight;
  kw_id = _n_; source = 'SEED';
  datalines;
ROOT|PAY01.1||system error|1
ROOT|PAY01.1||system outage|1
ROOT|PAY01.1||technical fault|1
ROOT|PAY01.1||payment failed|0.5
ROOT|PAY01.2||keying error|1
ROOT|PAY01.2||wrong account|0.5
ROOT|PAY01.2||manual error|1
ROOT|PAY01.2||processed incorrectly|1
ROOT|PAY02.1||fraud alert|0.5
ROOT|PAY02.1||failed to block|1
ROOT|PAY02.1||did not act|0.5
ROOT|PAY02.1||fraud team delay|1
ROOT|PAY02.2||scam warning|1
ROOT|PAY02.2||no warning|0.5
ROOT|PAY02.2||should have intervened|1
ROOT|ACC01.1||locked out|1
ROOT|ACC01.1||verification failed|1
ROOT|ACC01.1||security check|0.5
ROOT|ACC01.2||changed without consent|1
ROOT|ACC01.2||details amended|0.5
ROOT|ACC01.2||incorrect change|1
ROOT|ACC02.1||fee applied incorrectly|1
ROOT|ACC02.1||charged twice|1
ROOT|ACC02.1||refund fee|0.5
ROOT|ACC02.2||fee not disclosed|1
ROOT|ACC02.2||not made clear|0.5
ROOT|ACC02.2||terms unclear|0.5
ROOT|LND01.1||affordability assessment|1
ROOT|LND01.1||declined incorrectly|1
ROOT|LND01.1||income miscalculated|1
ROOT|LND01.2||application delay|1
ROOT|LND01.2||decision took longer|1
ROOT|LND01.2||awaiting decision|0.5
ROOT|LND02.1||excessive calls|1
ROOT|LND02.1||collections contact|0.5
ROOT|LND02.1||arrears letter|0.5
ROOT|LND02.2||vulnerability|1
ROOT|LND02.2||did not recognise|0.5
ROOT|LND02.2||bereavement|0.5
ROOT|SVC01.1||no response|1
ROOT|SVC01.1||failed to reply|1
ROOT|SVC01.1||chased|0.5
ROOT|SVC01.2||incorrect information|1
ROOT|SVC01.2||wrongly told|1
ROOT|SVC01.2||conflicting advice|1
ROOT|SVC02.1||unsuitable advice|1
ROOT|SVC02.1||poor advice|1
ROOT|SVC02.1||misled|0.5
ROOT|SVC02.2||rude|1
ROOT|SVC02.2||dismissive|1
ROOT|SVC02.2||unprofessional|1
TRIGGER||T01|out of pocket|1
TRIGGER||T01|hardship|1
TRIGGER||T01|lost money|1
TRIGGER||T01|overdrawn|0.5
TRIGGER||T02|hours on the phone|1
TRIGGER||T02|still waiting|1
TRIGGER||T02|had to chase|1
TRIGGER||T02|waited weeks|1
TRIGGER||T03|not fair|1
TRIGGER||T03|ignored|1
TRIGGER||T03|misled|1
TRIGGER||T03|lied|1
TRIGGER||T04|stressed|1
TRIGGER||T04|anxious|1
TRIGGER||T04|worried|0.5
TRIGGER||T04|embarrassed|1
TRIGGER||T05|disgusted|1
TRIGGER||T05|furious|1
TRIGGER||T05|appalling|1
TRIGGER||T05|unacceptable|1
;
run;

/*---- Integrity check: every keyword must point at a valid parent ---------*/
proc sql;
  title 'ORPHAN KEYWORDS (should return 0 rows)';
  select k.kw_id, k.keyword from cmp.kw_map k
   where (k.kw_type='ROOT'    and k.l3_id  not in (select l3_id  from cmp.tax_l3))
      or (k.kw_type='TRIGGER' and k.trg_id not in (select trg_id from cmp.tax_trigger));
quit;
title;
