/*==========================================================================
  04  FUZZY SEARCH + STRING DISTANCE AGAINST THE TAXONOMY KEYWORDS
  Strategy: match the VOCABULARY once (distinct n-grams x keywords), not every
  row.  Then join the small mapping table back to the sentences.
  Tools: complev() (Levenshtein), spedis() (spelling distance), soundex() boost.
  In : cmp.df_idf, cmp.ngrams_stem, cmp.kw_norm, cmp.tfidf
  Out: cmp.match_map, cmp.kw_hits, cmp.sim_l3
==========================================================================*/
%let fz_min     = 0.80;   /* minimum similarity to accept a fuzzy match     */
%let fz_minlen  = 6;      /* never fuzzy-match very short strings (pay/day) */

/*---- 1. Vocabulary (all distinct stemmed n-grams, incl. pruned ones) -----*/
proc sql;
  create table work.vocab as
  select distinct ngram, n from cmp.ngrams_stem;

  /*---- 2. Exact matches ---------------------------------------------------*/
  create table work.exact as
  select v.ngram, v.n, k.kw_id, 1 as match_q, 'EXACT' as match_type length=5
    from work.vocab v inner join cmp.kw_norm k
      on v.ngram = k.kw_stem and v.n = k.ngram_n;

  /*---- 3. Fuzzy candidates: blocked by n-gram size and length band -------*/
  create table work.fz_cand as
  select v.ngram, v.n, k.kw_id, k.kw_stem,
         complev(strip(v.ngram), strip(k.kw_stem))            as lev,
         spedis (strip(v.ngram), strip(k.kw_stem))            as spd,
         (soundex(compress(v.ngram)) = k.kw_sdx)              as sdx_hit,
         max(length(v.ngram), length(k.kw_stem))              as maxlen
    from work.vocab v inner join cmp.kw_norm k
      on  v.n = k.ngram_n
      and abs(length(v.ngram) - length(k.kw_stem)) <= 3
      and length(v.ngram) >= &fz_minlen.
      and v.ngram ne k.kw_stem;
quit;

/*---- 4. Score candidates, keep the best keyword per (ngram, kw_id) -------*/
data work.fuzzy;
  set work.fz_cand;
  length match_type $5;
  sim_lev = 1 - lev / maxlen;
  sim_spd = max(0, 1 - spd / 100);
  match_q = max(sim_lev, sim_spd) + (0.05 * sdx_hit);
  match_q = min(match_q, 0.99);                 /* a fuzzy hit never equals an exact hit */
  match_type = 'FUZZY';
  if match_q >= &fz_min.;
  keep ngram n kw_id match_q match_type;
run;

data cmp.match_map;
  set work.exact work.fuzzy;
run;

/*---- 5. Row-level hits, carrying the field and section tags -------------*/
proc sql;
  create table cmp.kw_hits as
  select g.complaint_id, g.field, g.sect, g.sent_no,
         k.kw_id, k.kw_type, k.l3_id, k.trg_id, k.kw_weight,
         m.match_type, m.match_q,
         coalesce(d.idf, 1) as idf
    from cmp.ngrams_stem g
    inner join cmp.match_map m on g.ngram = m.ngram and g.n = m.n
    inner join cmp.kw_norm   k on m.kw_id = k.kw_id
    left  join cmp.df_idf    d on g.ngram = d.ngram and g.n = d.n;
quit;

/*---- 6. Similarity matrix: complaint vector vs. L3 keyword vector --------*/
proc sql;
  create table cmp.sim_l3 as
  select t.complaint_id, t.field, k.l3_id,
         sum(t.tfidf_norm * k.kw_weight * m.match_q)
           / sqrt(l.kw_norm2) as cosine
    from cmp.tfidf t
    inner join cmp.match_map m on t.ngram = m.ngram and t.n = m.n
    inner join cmp.kw_norm   k on m.kw_id = k.kw_id and k.kw_type = 'ROOT'
    inner join (select l3_id, sum(kw_weight**2) as kw_norm2
                  from cmp.kw_norm where kw_type = 'ROOT' group by l3_id) l
      on k.l3_id = l.l3_id
   group by t.complaint_id, t.field, k.l3_id, l.kw_norm2;
quit;

proc sql;
  title 'Fuzzy matches accepted (audit these before trusting them)';
  select ngram, kw_id, put(match_q, 5.2) as sim from cmp.match_map where match_type = 'FUZZY';
quit; title;
